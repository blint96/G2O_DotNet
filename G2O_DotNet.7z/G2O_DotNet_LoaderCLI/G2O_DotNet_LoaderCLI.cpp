// G2O_DotNet_LoaderCLI.cpp : Defines the exported functions for the DLL application.
/*Own Code*/
#include "defines.h"
//using namespace System;
//using namespace System::IO;
//using namespace System::Reflection;
#include <iostream>

extern "C"
{
	// Module init function
	int EXPORT sqmodule_load_G2O_DotNet_LoaderCLI(void* vm, void* api)
	{
		std::cout << "[G2O_DotNetLoader] Test" << std::endl;
	//	Console::WriteLine("[G2O_DotNetLoader] Test");
		//String^ file = Path::Combine(Environment::CurrentDirectory, "G2O_DotNet.dll");
		//if (File::Exists(file))
		//{
		//	try
		//	{
		//		//Load assembly
		//		Assembly^ loadedAsm = Assembly::LoadFrom(file);
		//		//Find static Entry class.
		//		for each (Type^ type in loadedAsm->GetTypes())
		//		{				
		//			if (type->Name == "Entry")
		//			{						
		//				for each (MethodInfo^ method in type->GetMethods())
		//				{
		//					//Find Main method.
		//					if (method->Name == "Main")
		//					{
		//						array<Object^>^ paramterArray = gcnew array<Object^>(2);
		//						paramterArray[0] = gcnew IntPtr(vm);
		//						paramterArray[1] = gcnew IntPtr(api);

		//						method->Invoke(nullptr, paramterArray);
		//						Console::WriteLine("[G2O_DotNetLoader] G2O_DotNet loaded");
		//						return 1;
		//					}
		//				}
		//			}
		//		}
		//		Console::WriteLine("[G2O_DotNetLoader] no G2O_DotNet entry point found.");
		//		return -1;
		//	}
		//	catch (Exception^ ex)
		//	{
		//		Console::WriteLine("[G2O_DotNetLoader] G2O_DotNet could not be loaded");
		//		return -1;
		//	}
		//}
		//else
		//{
		//	Console::WriteLine("[G2O_DotNetLoader] G2O_DotNet.dll could not be found!!");
		//	return -1;
		//}
		return 0;
	}


}