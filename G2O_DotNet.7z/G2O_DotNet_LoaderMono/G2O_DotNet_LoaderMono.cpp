// G2O_DotNet_LoaderMono.cpp : Defines the exported functions for the DLL application.
//
#pragma once
#include <iostream>

/*Mono*/
#include <mono/mini/jit.h>
#include <mono/metadata/assembly.h>
#include <mono/metadata/object.h>
#include <mono/metadata/environment.h>
#include <mono/metadata/debug-helpers.h>
/*Own Code*/
#include "defines.h"



extern "C"
{
	// Module init function
	int EXPORT sqmodule_load(void* vm, void* api)
	{
		std::string namespaceName = "GothicOnline.G2.MonoInterface";
		std::string assemblyName = namespaceName + ".dll";
		std::string className = "Program";
		std::string mainMethod = "Main";

		//create a app domain and load the interface assembly
		MonoDomain*	domain = mono_jit_init(namespaceName.c_str());
		MonoAssembly *	assembly = mono_domain_assembly_open(domain, assemblyName.c_str());
		if (!assembly)
		{
			//assembly not found
			mono_jit_cleanup(domain);
			std::cout << "[DotNetLoader] Failed to load managed interface '" << assemblyName.c_str() << "'!" << std::endl;
			return -1;
		}
		else
		{
			//find the Program class and the Main method
			MonoImage * img = mono_assembly_get_image(assembly);
			MonoClass*  managedClass = mono_class_from_name(img, namespaceName.c_str(), className.c_str());
			MonoMethod*	method = mono_class_get_method_from_name(managedClass, mainMethod.c_str(), 2);

			//method not found 
			if (method == nullptr)
			{
				mono_jit_cleanup(domain);
				std::cout << "[DotNetLoader] Failed to find initialization method '" << mainMethod.c_str() << "'" << std::endl;
				return -1;
			}
			else
			{

				std::cout << "[DotNetLoader]G2O DotNetLoaderMono " << LOADER_VERSION << " loaded" << std::endl;

				//call the main method
				void* args[2];
				args[0] = &vm;
				args[1] = &api;
				mono_runtime_invoke(method, nullptr, args, nullptr);
				return 1;
			}
		}
	}
}


